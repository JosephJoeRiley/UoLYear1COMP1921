#ifndef __PGM_ECHO__
#define __PGM_ECHO__
#include "pgmImage.h"
#include "pgmRead.h"
#include "pgmWrite.h"
int main(int argc, char** argv);
#endif //__PGM_ECHO__