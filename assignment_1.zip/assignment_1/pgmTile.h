#ifndef __PGM_TILE__
#define __PGM_TILE__
#include <math.h>
#include "pgmImage.h"
#include "pgmErrors.h"
#include "pgmRead.h"
#include "pgmWrite.h"

#endif //__PGM_TITLE__